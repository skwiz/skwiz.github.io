require("wizard/wizard").default.create().start();
//# sourceMappingURL=/assets/wizard-start-f142a86a7c6379e363875dc55b832b2c0ecd6d59c391af4c9d00ff34e41f9ed0.js.map