document.addEventListener("DOMContentLoaded",(function(){window.print()}));
//# sourceMappingURL=/assets/print-page-e36056a4075e3fd3032cbf30b45aa1ce743abe55bf79f9e92429f33446f0801b.js.map